<!DOCTYPE html>
<html>
<body>

<?php

function hngTask() {
  echo "Hello World, this is [Stephen] [Mangai] with HNGi7 ID [HNG-05025] using [PHP] for stage 2 task.  sm120@students.kiron.ngo";
}

hngTask();

?>

</body>
</html>