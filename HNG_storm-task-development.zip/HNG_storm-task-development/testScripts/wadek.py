import json
wadek_info = {
	'fName': "[Derrick]",
	'lName': "[Wadek]",
	'id': "[HNG-00080]",
	'email': "[derrickwadek@mail.com]",
	'language': "[Python]",
}
print("Hello world, this is {} {} with HNGi7 ID {} using {} for stage 2 task. {}.".format(
    wadek_info['fName'], wadek_info['lName'], wadek_info['id'], wadek_info['language'], wadek_info['email']))