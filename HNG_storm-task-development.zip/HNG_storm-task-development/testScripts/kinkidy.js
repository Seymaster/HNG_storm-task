let firstName= "Ahmad";
    lastName= "Yusuf";
    hngId= "HNG-05220";
    language= "javaScript";
    email= "kinkidycodes@gmail.com";

const task = () => {
    console.log (`Hello World, this is [${firstName}] [${lastName}] with HNGi7 ID [${hngId}] using [${language}] for stage 2 task. ${email}`);
};

task();

