<?php

$name = "[Ikumapayi] ";
$name.= "[Timileyin]";
$hng_id = "HNG-04738";
$lang = "PHP";
$email = "ikumapayioluwatimileyin@gmail.com";

print("Hello World, My name is $name, my HNGi7 ID is [$hng_id] using [$lang] for stage 2 task. $email");

?>
