
def task():
	fname = "[Joshua]"
	lname = "[Hassan]"
	HNG_ID = "[HNG-00533]"
	email = "cutejosh2@gmail.com"
	language = "[Python]"
	# using string concatenation
	print("Hello World, this is {} {} with HNGi7 ID {} using {} for stage 2 task. {}".format(fname, lname, HNG_ID, language, email))

task()