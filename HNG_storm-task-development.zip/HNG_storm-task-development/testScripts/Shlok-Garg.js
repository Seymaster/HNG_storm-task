var FirstName='Shlok' , LastName='Garg' , id='HNG-01167' , language='Javascript' , mail='sngargrsd@gmail.com';
var result = 'Hello World, this is [' + FirstName +'] [' + LastName + '] with HNGi7 ID [' + id + '] using [' + language + '] for stage 2 task. ' + mail ;

console.log(result);