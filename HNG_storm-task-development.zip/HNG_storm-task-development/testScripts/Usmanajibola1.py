def task():
    first_name = "Usman"
    last_name = "Abass"
    email = "usmanajibolaabass@gmail.com"
    my_id = "HNG-05550"
    language= "python"

    reply = "Hello World, this is" + str([first_name]) + str([last_name]) +  "with HNGi7 ID" + str([my_id]) + "using" + str([language]) + "for stage 2 task." + str(email) 
    return reply


