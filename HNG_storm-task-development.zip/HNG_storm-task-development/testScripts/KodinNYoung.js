const firstName = "Abiodun",
	lastName = "Adebambo",
	hngi7ID = "HNG-00695",
	language = "Javascript",
	email = "abiodunadebambo869@yahoo.com",
	output = `Hello World, this is [${firstName}] [${lastName}] with HNGi7 ID [${hngi7ID}] using [${language}] for stage 2 task. [${email}]`;

console.log(output); 