(function () {
  const full_name = 'Hafizah Muhyideen ';
  const ID = 'HNG-02396';
  const language = 'JavaScript';
  const email = 'Hafeexahabdul@gmail.com';

  console.log(
    `Hello World, this is ${full_name} with HNGi7 ID ${ID} and email ${email} using ${language} for stage 2 task`
  );
})();
