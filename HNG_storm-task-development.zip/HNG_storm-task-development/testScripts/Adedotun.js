function output() {
    var data = {
        firstName: "[Adedigba]",
        lastName: "[Adedotun]",
        language: "[Javascript]",
        id: "[HNG-02336]",
    };

    console.log("Hello World, this is " + data.firstName + " " + data.lastName + " with HNGi7 ID " + data.id + " using " +
                 data.language + " for stage 2 task. adedigbaadedotun2000@gmail.com");
}

output();