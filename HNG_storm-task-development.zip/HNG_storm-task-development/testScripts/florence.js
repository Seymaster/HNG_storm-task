//declare the variables
const fName = "[Florence]";
const lName = "[Wanjiru]";
const hngId = "[HNG-01113]";
const language = "[JavaScript]";    
const email= "florenceshiru765@gmail.com";
    
//output
console.log(`Hello World, this is ${fName} ${lName} with HNGi7 ID ${hngId} using ${language} for stage 2 task. ${email}`);
