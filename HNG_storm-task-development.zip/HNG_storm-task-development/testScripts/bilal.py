def task1():
    firstName = "[Mohammad]"
    LastName = "[Bilal]"
    id = "[HNG-03370]"
    email = "mohdbilal16@gmail.com"
    language = "[Python]"
    print("Hello World, this is " + firstName + " " + LastName  + " with HNGi7 ID " + id + " using "  + language + " for stage 2 task. " + email);
task1()
