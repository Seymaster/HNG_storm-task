const display =() => {
	
return `Hello World, this is [Gift] [Maduabuchi] with HNGi7 ID [HNG-00767] using [javascript] for stage 2 task. giftmaduabuchi@gmail.com`;
}
	console.log(display());