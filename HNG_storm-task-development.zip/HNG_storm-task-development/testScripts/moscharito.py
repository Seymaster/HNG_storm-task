def task2():

  firstname = "[Moshood]"
  lastname = "[Salaudeen]"
  hngid = "[HNG-01122]"
  email = "bolaji.moscharito@gmail.com"
  language = "[python]"
  print("Hello World, this is", firstname, lastname, "with HNGi7 ID", hngid, "using", language, "for stage 2 task.", email)
task2()