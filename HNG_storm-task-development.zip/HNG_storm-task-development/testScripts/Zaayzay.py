# Sript created by Zaynab Awofeso for HNGi7 intern
firstName = '[Zaynab]'
lastName = '[Awofeso]'
hngi7_id = '[HNG-01062]'
language = '[python]'
email = 'zayawofeso@gmail.com'

print('Hello World, this is' + ' ' + firstName + ' ' + lastName + ' ' + 'with HNGi7 ID' + ' ' + hngi7_id.upper() + ' ' + 'using' + ' ' + language + ' ' + 'for stage 2 task.' + ' ' + email)
