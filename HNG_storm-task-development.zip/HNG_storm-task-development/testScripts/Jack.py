#!/usr/bin/env python3

print("Hello World, this is [Jack] [Ojee] with HNGi7 ID [HNG-06346] using [python] for stage 2 task. jackojee98@gamil.com")
