// jshint esversion:8
(function log(){
  const firstName = 'Akanowo';
  const lastName = 'Uko';
  const hngID = 'HNG-05016';
  const lang = 'Javascript';
  const email = 'ukoakanowo98@gmail.com';
  
  return console.log(`Hello World, this is ${[firstName]} ${[lastName]} 
  with HNGi7 ID ${[hngID]} using ${[lang]} for stage 2 task. ${email}"`);
}());
