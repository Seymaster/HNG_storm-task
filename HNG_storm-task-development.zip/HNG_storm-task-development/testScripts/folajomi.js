const data = {
    firstName: "Folajomi",
    lastName: "Shotunde",
    email: "folajor.mee@gmail.com",
    id: "HNG-06103",
    language: "JavaScript"
}

console.log(`Hello World, this is [${data.firstName}] [${data.lastName}] with HNGi7 ID [${data.id}] using [${data.language}] for stage 2 task. ${data.email}`)