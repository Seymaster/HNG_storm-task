function dayo(){
	console.log("Hello World, this is [Adedayo] [Adeniyi] with HNGi7 ID [HNG-04202] using [Javascript] for stage 2 task. adeniyiadedayo95@yahoo.com");
}
dayo();