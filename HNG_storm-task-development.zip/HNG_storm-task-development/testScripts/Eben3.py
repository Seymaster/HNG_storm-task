my_id = "[HNG-02690]"
my_name = "[Owologba Ebenezar]"
my_language = "[Python]"

print("Hello World, this is %s with HNGi7 ID %s using %s for stage 2 task. rowendduke36@gmail.com" % (my_name,my_id,my_language))
