const me = {
    Firstame: 'Oluwatobi',
    Lastame: 'Ogunwole',
    hngid: 'HNG-05517',
    Language: 'Javascript',
    email: 'oluwatstar21@gmail.com'
}

let output = 'Hello World, this is ['+me.Firstame+'] ['+me.Lastame+'] with HNGi7 ID ['+me.hngid+'] using ['+me.Language+'] for stage 2 task. '+me.email
console.log(output)