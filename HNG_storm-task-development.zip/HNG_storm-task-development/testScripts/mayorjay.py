my_first_name = 'Joseph'
my_last_name = 'Olugbohunmi'
my_id = 'HNG-00755'
my_email = 'joseolu4gsm@yahoo.com'
my_lang = 'Kotlin'

print('Hello World, this is [{}] [{}] with HNGi7 ID [{}] using [{}] for stage 2 task. {}'.format(my_first_name, my_last_name, my_id, my_lang, my_email))
