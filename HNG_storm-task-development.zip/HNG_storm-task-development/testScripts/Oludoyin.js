data = {
    fname : "Adenuga",
    lname : "Oludoyin",
    id : "HNG-01248",
    language : "Javascript",
    email : "Otegbeye44@gmail.com"
  };
  
  
  
  console.log ("Hello World, this is " + data.fname + " " + data.lname + " " + "with HNGi7 ID" + " " + data.id + " " + "using" + " " + data.language + " " + "for stage 2 task." + " " + data.email);