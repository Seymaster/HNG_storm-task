function gkb(){
  let myDetails = {
    firstName: "Kufreabasi",
    lastName: "Udoh",
    language: "Javascript",
    id: "HNG-02359",
    email: "udoh.kufre.m@gmail.com"
  };

  return "Hello World, this is [" + myDetails.firstName + "] [" + myDetails.lastName + "] with HNGi7 ID [" + myDetails.id + "] using [" + myDetails.language + "] for stage 2 task. " + myDetails.email
}
console.log(gkb());

gkb();