firstname= "Brian"
lastname = "Orina"
language = "Python"
email ="brayohorina@gmail.com"

def print_details(fname,lname,lang,email):
    print(f"Hello World, [{firstname}][{lastname}] with HNG-0000 using [{language}] for stage 2 task. {email}")

print_details(firstname,lastname,language,email)