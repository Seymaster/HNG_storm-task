function hngteamtask() {
    const FirstName = "[Oluwaseun]";
    const LastName = "[Iyiola]";
    const HngID = "[HNG-02107]";
    const Language = "[Javascript]";
    const Email = "holuwaseun50@gmail.com";

console.log(
    "Hello World, this is",FirstName,LastName,"with HNGi7 ID",HngID,"using",Language,"for stage 2 task.",Email
);
}
hngteamtask();