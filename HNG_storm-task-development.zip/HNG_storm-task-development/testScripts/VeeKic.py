firstName="[Victory]"
LastName="[Wekwa]"
id="[HNG-01926]"
Language="[Python]"
email="victorywekwa@gmail.com"
print("Hello World, this is"+" "+firstName +" "+LastName+" "+"with HNGi7 ID" +" "+ id + " " + "using" +" " +Language + " " + "for stage 2 task."+" "+email)