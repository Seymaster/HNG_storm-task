def output():
    firstName = "[Yahaya]"
    LastName = "[Suleiman]"
    id = "[HNG-05948]"
    email = "yahaya.suleiman2204@gmail.com"
    language = "[Python]"
    x = {
    "firstName": "Yahaya",
        "lastName": "Suleiman",
        "language": "Python",
        "id": "HNG-05948",
    }


    print("Hello World, this is " + firstName + " " + LastName  + " with HNGi7 ID " + id + " using "  + language + " for stage 2 task. " + email);

output()
