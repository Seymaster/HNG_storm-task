def myInfo(firstName,lastName,hngID,language,mail):
    print("Hello World, this is ", firstName, lastName ,' with HNGi7 ID ',hngID, ' using ', language, ' for stage 2 task. ',mail)

myInfo(firstName ='[Ndubuisi]',
    lastName = '[Ugwulo]',
    hngID = '[HNG-02099]',
    language = '[python]',
    mail = 'seanlite94@gmail.com')