const resultsHng = function (firstName = "Steve", lastName = "Waweru", id = "HNG-01325", language = "Javascript", email = "wawerusteve142@gmail.com") {
  return `Hello World, this is [${firstName}] [${lastName}] with HNGi7 ID [${id}] using [${language}] for stage 2 task. ${email}`
}
resultsHng()
console.log(resultsHng())
