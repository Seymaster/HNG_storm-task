const output = (firstName, lastName, id, language) => (
    `Hello World, this is [${firstName}] [${lastName}] with HNGi7 ID [${id}] using [${language}] for stage 2 task. osujichukwuamaka@gmail.com`
);

console.log(output("Chukwuamaka", "Osuji", "HNG-02839" , "JavaScript"));