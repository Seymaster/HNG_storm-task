def Data():
	first_name = "Believe"
	last_name = "Amadi"
	user_id = "HNG-01841"
	language = "Python"
	email = "believemanasseh@gmail.com"

	return ("Hello World, this is [{}] [{}] with HNGi7 ID [{}] using [{}] for stage 2 task. {}".format(first_name, last_name, user_id, language, email))

print(Data())
