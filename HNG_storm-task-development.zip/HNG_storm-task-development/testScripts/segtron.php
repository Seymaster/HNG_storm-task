<?php

echo "Hello World, this is [Bello] [Wasiu] with HNGi7 ID [HNG-00662] using [PHP] for stage 2 task.shegthron102@gmail.com";
