const declare = () =>{
 console.log(`Hello World, this is [Akanimo] [Akpan] with HNG7 ID [HNG-02228] using [javascript] for stage 2 task. akanimoime2016@gmail.com`);
}

declare()
