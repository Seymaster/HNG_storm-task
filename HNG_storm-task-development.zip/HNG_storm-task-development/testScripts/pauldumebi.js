var hello = "Hello World, this is "
var fname = "[Paul] ";
var lastName = "[Chukwurah] ";
var text = "with HNGi7 ID ";
var id = "[HNG-01940] ";
var text2 = "using "
var lang = "[JavaScript] ";
var text3 = "for stage 2 task. "
var eMail = "paulchukwurah7@gmail.com"

var result = hello.concat(fname, lastName, text, id, text2, lang, text3, eMail);
console.log(result)
