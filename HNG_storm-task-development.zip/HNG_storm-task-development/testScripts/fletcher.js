const my_script = () => {
    const data = {
        name : 'OLUFEMI EZEKIEL OLUFEMI',
        id : 'HNG-04946',
        language : 'javascript'
    }
    return `Hello World, this is ${data.name} with HNGi7 ID ${data.id} using ${data.language} for stage 2 task. ezekielolufemi09@yahoo.com`;
    console.log(my_script);
};

    my_script();