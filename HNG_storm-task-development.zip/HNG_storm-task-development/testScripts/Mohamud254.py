def stage_two_task(firstname, lastname, id, language, email):
    print(f"Hello world, this is [{firstname}] [{lastname}] with HNGi7 ID [{id}] using [{language}] for stage 2 task. {email}")
     
stage_two_task("Mohamud", "Rashid", "HNG-03991", "python", "rashidmohamud9865@gmail.com")