def main():
    print("Hello world, this is [Chisom Aniekwensi] with HNGi7 ID [02509] using [python] for stage 2 task. sommaniekwensi@gmail.com")


if __name__ == '__main__':
    main()
    