const davetech = (firstname, lastname, id, lang, email) => {
    console.log(`Hello World, this is [${firstname}] [${lastname}] with HNGi7 ID [${id}] using [${lang}] for stage 2 task. ${email}`);
}

davetech('Ajayi', 'David', 'HNG-01671', 'Javascript', 'david.ajayi.anu@gmail.com');