const secondTask = () => {
    const firstName = 'Adetola';
    const lastName = 'Adebola';
    const language = 'javascript';
    const id = 'HNG-00148';
    const email = 'adebolaadetola65@gmail.com'
    return `Hello World, this is [${firstName}] [${lastName}] with HNGi7 ID [${id}] using [${language}] for stage 2 task. ${email}`
}
console.log(secondTask());
