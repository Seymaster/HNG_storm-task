
const airdata = {
	file: "airon.js",
	fname: "Aniebiet",
	lname: "Aaron",
	message: "Hello World, this is [Aniebiet] [Aaron] with HNGi7 ID [HNG-03203] using [Javascript] for stage 2 task. airondev@gmail.com",
	id: "HNG-03203",
	email: "airondev@gmail.com",
	language: "Javascript", 
};

str_output = `Hello World, this is [${airdata.fname}] [${airdata.lname}] with HNGi7 ID [${airdata.id}] using [${airdata.language}] for stage 2 task. ${airdata.email}`;
console.log(str_output);

