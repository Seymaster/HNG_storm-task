const firstname = "Peter";
const lastname="IsraelOvirih"
const id = "HNG-03234";
const language = "Javascript";
const email = "peterisrael98@gmail.com"

function Mine(){
    console.log (`Hello World, this is [${firstname}] [${lastname}] with HNGi7 ID [${id}] using [${language}] for stage 2 task. ${email}`);
}

Mine();