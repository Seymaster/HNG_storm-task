FirstName = "[Blessing]"
LastName = "[Okakwu]"
HNG_ID = "[HNG-01951]"
Lang = "[Python]"
email = "bokakwu@gmail.com"

print("Hello world, this is" + " " + FirstName + " " + LastName + " with HNGi7 ID " + HNG_ID + " using " + Lang + " for stage 2 task." + " " + email)