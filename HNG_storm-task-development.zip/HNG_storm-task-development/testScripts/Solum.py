# -*- coding: utf-8 -*-
"""
Created on Thu Jun  4 02:04:32 2020

@author: uogude
"""


def HNG():
    func = print("Hello World, this is [Uwaoma] [Ogude] with HNGi7 ID [HNG-05492] using [python] for stage 2 task. kenogude09@gmail.com")
    return func
HNG()
