# HNGi7 Task2. SlackID - orekoko

def hng_task2():
	"""Returns the required string as per HNGi7 task 2"""
	firstname = 'Oreoluwa'
	lastname = 'Adetimehin'
	hng_ID = 'HNG-03448'
	language = 'Python'
	email = 'adetimehinoreoluwa@gmail.com'
	message = 'Hello World, this is [' + firstname + '] [' + lastname + '] with HNGi7 ID [' + hng_ID + '] using [' + language + '] for stage 2 task. ' + email
	
	print(message)

# Output the required
hng_task2()