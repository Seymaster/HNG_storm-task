# import json

first_name = '[Osamudiamen]'
last_name = '[Azamegbe]'
# full_name = first_name + " " + last_name
HNG_id = '[HNG-00028]'
language = '[python]'
email = "osas.azamegbe@gmail.com"

output = f"Hello World, this is {first_name} {last_name} with HNGi7 ID {HNG_id} using {language} for stage 2 task. {email}"
print(output)