import json

#Script written by Kang Breder
#This script outputs a string on the console.

firstName = "[Kang]"
lastName = "[Breder]"
internshipId = "[HNG-03939]"
language = "[Python]"
email = "kangbreder@gmail.com"

print("Hello World, this is % s % s with HNGi7 ID % s using % s for stage 2 task. % s" 
% (firstName, lastName, internshipId, language, email))