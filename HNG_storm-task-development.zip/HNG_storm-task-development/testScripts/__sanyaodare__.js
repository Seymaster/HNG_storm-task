function myDetails(firstName, lastName, id, language, email) {    
    return `Hello World, this is ${firstName} ${lastName} with HNGi7 ID ${id} using ${language} for stage 2 task. ${email}`;
}
console.log(myDetails("[Sanya]", "[Oluwadare]", "[HNG-00202]", "[JavaScript]", "sanyaodare@gmail.com"));