<?php 
function hngname(){
    print("Hello World, this is [Oluwanifemi] [Bamgbose] with HNGi7 ID [HNG-01392] using [PHP] for stage 2 task. nifemibams@gmail.com");
}

hngname();
?>
