function task2() {
  const Fname = "[Habeebullah]";
  const Lname = "[Agbaje]";
  const HNGID = "[HNG-04846]";
  const lang = "[javascript]";

  console.log(
    "Hello World, this is",
    Fname,
    Lname,
    "with HNGi7 ID",
    HNGID,
    "using",
    lang,
    "for stage 2 task. agbajeh8@gmail.com"
  );
}
task2();
