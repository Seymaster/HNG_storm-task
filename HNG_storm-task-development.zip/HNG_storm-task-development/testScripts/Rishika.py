def Intern(first, last, lang, id):


    print("Hello World, this is {} {} with HNGi7 ID {} using {} for stage 2 task. rishikaroy1802@gmail.com".format(first, last, id, lang))

Intern("Rishika", "Roychoudhury", "Python", "HNG-01831")