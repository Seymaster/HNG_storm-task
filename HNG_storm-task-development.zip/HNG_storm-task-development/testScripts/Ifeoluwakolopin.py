def helloWorld():
    return "Hello World, this is [Ifeoluwakolopin] [Are] with HNGi7 ID [HNG-02512] using [Python] for stage 2 task. areifeoluwa10@gmail.com"

print(helloWorld())
