#function to print out my details
def output():
    print("Hello World, this is [KerenHappuch] [Achoja] with HNGi7 ID [HNG-01748] using [Python] for stage 2 task. gkay260@gmail.com")
    return


output()