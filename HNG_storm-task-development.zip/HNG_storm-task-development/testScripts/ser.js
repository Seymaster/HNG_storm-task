function output(){
    const data ={
        firstName:"Ser",
        lastName:"Raphaels",
        language:"JavaScript",
        id:"HNG-04554",
    };
    str="Hello World, this is [Ser] [Raphaels] with HNGi7 ID [HNG-04554] using [JavaScript] for stage 2 task. oseraphaels@gmail.com";
    return str;
}
console.log(output());