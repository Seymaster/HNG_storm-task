print(f"""Hello World, this is [Oluwatobi] [Adesanya] 
with HNGi7 ID [06135] using [Python] 
for stage 2 task. 
tobbey.adesamya@gmail.com """)