<?php

$arr = [ 
  "first_name"=> "Alozie",
  "last_name"=> "Ihuoma",
  "hng_id"=>"HNG-01252",
  "language"=> "PHP",
  "email"=> "alozie.ihuomao@gmail.com"
];

//echo("Hello World, this is");  echo $arr["first_name"];  echo $arr["last_name"]; echo('with HNGi7 ID'); echo($arr["hng_id"]); echo('using'); echo($arr["language"]); echo('for stage 2 task.'); echo $arr["email"];
echo('Hello World, this is [Alozie] [Ihuoma] with HNGi7 ID [HNG-01252] using [PHP] for stage 2 task. alozie.ihuomao@gmail.com');

?>