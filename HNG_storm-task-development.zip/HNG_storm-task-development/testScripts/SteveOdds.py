firstName = "[Stephen]"
lastName = "[Odundo]"
hngId = "[HNG-00039]"
lang = "[python]"
email = "steveremdi@gmail.com"

message = "Hello world, this is {0} {1} with HNGi7 ID {2} using {3} for stage 2 task. {4}".format( firstName, lastName, hngId, lang, email )
print(message, flush=True)