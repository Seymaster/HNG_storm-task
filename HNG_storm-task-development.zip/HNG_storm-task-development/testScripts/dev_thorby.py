# The script is to return this: "Hello World, this is [full name] with HNGi7 ID [ID] using [language] for stage 2 task". 

def my_hng_info (firstName, lastName, hng_id,language):

    print("Hello World, this is {} {} with HNGi7 ID {} using {} for stage 2 task. tobioyewole25@gmail.com".format(firstName, lastName, hng_id, language))

my_hng_info("[Oyewole]", "[Oluwatobi]","[HNG-04827]","[python]")


