<?php
//declare details
$first_name = "Tochukwu";
$last_name = "Ewiwilem";
$id = "HNG-03310";
$lang = "PHP";

//declare message
$message = "Hello World, this is [$first_name] [$last_name] with HNGi7 ID [$id]";
$message .= " using [$lang] for stage 2 task. tochukwu.ewiwilem@eng.uniben.edu";

//By default, all output goes to stdout, which is the HTTP response or the console
echo $message;
?>