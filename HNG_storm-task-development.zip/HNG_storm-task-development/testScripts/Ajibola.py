def task():
    first_name = "Kehinde"
    last_name = "Ajibola"
    id = "HNG-04260"
    language = "Python"
    mail = "ajibolakehinde511@gmail.com"
    output = (f'Hello World, this is [{first_name}] [{last_name}] with HNGi7 ID [{id}] using [{language}] for stage 2 task. {mail}')
    return output


print(task())