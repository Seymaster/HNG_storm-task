#declaration of variables
internFirstName = "[Mbora]"
internLastName = "[Githua]"
internID = "[HNG-00033]"
internLanguage = "[HTML]"
internEmail = "mbora.githua@gmail.com"

print(
    "Hello World, this is" + " " + internFirstName + " " + internLastName + " " + "with HNGi7 ID" + " " + internID + " " + "using" + " " + internLanguage + " " + "for stage 2 task." + " " + internEmail
)

