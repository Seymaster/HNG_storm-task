let firstName = "[Oreva]";
let lastName = "[Eniworo]";
let hngID = "[HNG-05131]";
let language = "[JavaScript]";

console.log("Hello World, this is " +firstName+ " " +lastName+ " with HNGi7 ID " 
+hngID+ " using " +language+ " for stage 2 task. eniworoeva@yahoo.com");