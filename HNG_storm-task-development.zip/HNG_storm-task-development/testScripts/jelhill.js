let jelhill = {
    firstname: "Abduljelili",
    lastname: "Umaru",
    id: "HNG-00204",
    language: "Javascript",
    email: "talk2jelili2000@gmail.com",
}
  
  console.log(`Hello World, this is [${jelhill.firstname}] [${jelhill.lastname}] with HNGi7 ID [${jelhill.id}] using [${jelhill.language}] for stage 2 task. ${jelhill.email}`)