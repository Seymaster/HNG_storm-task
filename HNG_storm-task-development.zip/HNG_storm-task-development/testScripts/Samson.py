firstname = "[Kayode]"
lastname = "[Samson]"
language = "[Python]"
id = "[HNG-00727]"
email = "samcity39.sk@gmail.com"
print("Hello World, this is {} {} with HNGi7 ID {} using {} for stage 2 task. {}".format
      (firstname, lastname, id, language, email))
