console.log(
  "Hello World, this is [Joshua] [Folorunsho] with HNGi7 ID [HNG-01389] using [JavaScript] for stage 2 task. joshuafolorunsho01@gmail.com"
);
