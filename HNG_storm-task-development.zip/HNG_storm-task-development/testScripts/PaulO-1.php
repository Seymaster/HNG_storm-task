<?php

$firstname = "Paul";

$lastname = "Okwudike";

$idtag = "HNG-U014K7F166P";

$pru = "PHP";

$email = "paulamaechiokwudike@gmail.com"

echo "Hello World, this is [firstname] [lastname] with HNGi7 ID [idtag] using [pru] for stage 2 task. [email]"


?>
