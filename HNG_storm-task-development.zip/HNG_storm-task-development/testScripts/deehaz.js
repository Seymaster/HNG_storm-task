const data = {
    firstName: "Zaheed",
    lastName: "Beita",
    id: "HNG-02613",
    email: "lordzeddy31@gmail.com",
    language: "Javascript",
};

console.log(`Hello World, this is [${data.firstName}] [${data.lastName}] with HNGi7 ID [${data.id}] using [${data.language}] for stage 2 task. ${data.email}`);
