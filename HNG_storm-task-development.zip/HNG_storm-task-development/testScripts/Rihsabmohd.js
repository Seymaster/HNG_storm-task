const name = "Mohammed Bashir Oladimeji"
const id = "HNG-02012"
const email = "rihsabmohd@gmail.com"
const language ="Javascript"



let printHello = () => {
	return `Hello World, this is ${name} with HNGi7  ID ${id} using ${language} for stage 2 task. ${email}`;
}

console.log(printHello());