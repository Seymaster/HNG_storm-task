const userInfo = {
    userFirstName : "Sylvester",
    userLasttName : "Agubata",
    userEmail: "agubatasylvester@gmail.com",
    ID: "HNG-03277",
    language:"JavaScript",

};

const myInfo = `Hello World, this is [${userInfo.userFirstName}] [${userInfo.userLasttName}] with HNGi7 ID [${userInfo.ID}]
using [${userInfo.language}] for stage 2 task. ${userInfo.userEmail}`;

console.log(myInfo);