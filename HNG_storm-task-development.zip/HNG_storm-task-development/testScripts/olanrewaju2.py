full_name = '[Olanrewaju] [Akinlade]'
hng_id = '[hng-01665]'
language = '[Python]'
email = 'topelanre30@gmail.com'
full_statement = ("Hello World," + " "+ "this is" +" "+ full_name + " " + "with HNGi7 ID" + " " + hng_id.upper() + " "+ "using" + " " + language + " " + "for stage 2 task" +"." + email)
print(full_statement)


