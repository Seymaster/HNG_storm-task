fname = "Karen"
lname = "Ngugi"
intern_id = 'HNG-03330'
language = "Python"

print("Hello World, this is [{}] [{}] with HNGi7 ID [{}] using [{}] for stage 2 task. karenwngugi12@gmail.com".format(fname, lname, intern_id, language), flush = True)
