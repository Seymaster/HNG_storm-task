#My task 1 python script
def task_one():
    first_name = "[Bockarie]"
    last_name = "[Lahai]"
    id_no = "[HNG-02418]"
    language = "[Python]"
    print("Hello World, this is {first_name} {last_name} \
with HNGi7 ID {id_no} using {language} \
for stage 2 task. bkahai94@gmail.com".format(first_name = first_name, last_name = last_name, id_no = id_no, language = language))
task_one()