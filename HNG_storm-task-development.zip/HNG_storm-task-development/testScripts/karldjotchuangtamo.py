'''
Script to Print "Hello World, this is [full name] with 
HNGI7 ID [ID] using [Language] for stage 2 task"

'''

my_surname = 'Karl'
my_name = 'Djotchuang'
id = 'HNG-05439'
language = 'Python'
email = 'djotchuangtamo@gmail.com'

text_string = 'Hello World, this is [' + my_surname + \
    '] [' + my_name + '] with HNGi7 ID [' + id + '] using [' + \
    language + '] for stage 2 task. ' + email

print(text_string)
