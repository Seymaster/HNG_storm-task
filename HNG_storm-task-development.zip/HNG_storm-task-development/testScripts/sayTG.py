first_name = "[ThankGod]"
last_name = "[Busari]"
email = "busarithienkie@gmail.com"
id_number = "[HNG-04616]"
language = "[Python]"

print("Hello World, this is {} {} with HNGi7 ID {} using {} for stage 2 task. {}".format(first_name, last_name, id_number, language, email))