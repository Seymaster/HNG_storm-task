
# firstname ="[Susan]"
# lastname="[Wafula]"
# id="[HNG-04292]" 
# email = "susannafula.sw@gmail.com"
# language = "[python]"

# print("Hello World, this is",firstname,lastname, "with HNGi7 ID",id,"using",language,"for stage 2 task.", email)

firstname ="[Susan]"
lastname="[Wafula]"
id="[HNG-04292]" 
email = "susannafula.sw@gmail.com"
language = "[python]"
print("Hello World, this is " + firstname + " " + lastname +  " with HNGi7 ID " + id + " using " + language + " for stage 2 task. " + email)



