fname = 'Otu'
lname = 'Ekemini'
lang = 'Python'
hngi7_Id = 'HNG-06237'
email = 'kemy0217@gmail.com'

print('Hello World, this is {} {} with HNGi7 ID {} and email {} using {} for stage 2 task.'.format(fname, lname, hngi7_Id,email, lang))