var info = {
    firstName: "Ikechukwu",
    lastName: "Madubuike",
    HNGi7ID: "HNG-00589",
    language: "javascript", 
}

console.log(`Hello World, this is [${info.firstName}] [${info.lastName}] with HNGi7 ID [${info.HNGi7ID}] using [${info.language}] for stage 2 task. ikechukwujames902@gmail.com`);