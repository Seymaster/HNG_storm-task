const userData = {
 firstName: 'Joachim',
 lastName: 'Junior',
 language: 'javascript',
 id: 'HNG-04353',
 email: 'joachimjunior5@gmail.com'
};
console.log('Hello World, this is [' + userData.firstName + '] [' + userData.lastName + '] with HNGi7 ID [' + userData.id + '] using [' + userData.language + '] for stage 2 task. ' + userData.email);
