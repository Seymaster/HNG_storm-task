fname = "Osazemen"
lname =  "Osaigbevo"
identity = "HNG-00724"
lang = "Python"
mail = "osaigbevo_osaz@yahoo.com"

def task_function():
    print("Hello world, this is [" + fname + "] [" + lname + "] with HNGi7 ID [" + identity + "] using [" + lang +
     "] for stage 2 task. " + mail)

task_function()
