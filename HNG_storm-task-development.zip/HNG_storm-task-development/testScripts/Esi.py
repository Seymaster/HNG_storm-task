def details(F,L,I,La,E):
    print("Hello World, this is",F,L,'with HNGi7 ID',I,'using', La,'for stage 2 task.',E)

details(
    F ='[Mercy]',
    L = '[Godwin]',
    I = '[HNG-00414]',
    La = '[python]',
    E ='gowinmercy@gmail.com')
