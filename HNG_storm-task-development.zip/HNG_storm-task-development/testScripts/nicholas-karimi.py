#!/usr/bin/env python3


"""A python script that prints my name and
    HNGi7 internship ID."""

def get_intern_details(firstName, lastName, lang, id):


    print("Hello World, this is {} {} with HNGi7 ID {} using {} for stage 2 task. nicholaskarimi.dev@gmail.com".format(firstName, lastName, id, lang))

get_intern_details("[Nicholas]", "[Karimi]", "[Python]", "[HNG-04333]")
