const FIRST_NAME = '[David]';
const LAST_NAME = '[Fabusuyi]';
const ID = '[HNG-03227]';
const LANGUAGE = '[Javascript]';
const EMAIL = 'dav4thevid@gmail.com'

function output(first_name,last_name,id, language, email) {
    console.log(`Hello World, this is 
    ${first_name} ${last_name} with HNGi7 ID 
    ${id} using ${language} for stage 2 task as its output. 
    ${email}`);
}

output(FIRST_NAME,LAST_NAME, ID, LANGUAGE, EMAIL);