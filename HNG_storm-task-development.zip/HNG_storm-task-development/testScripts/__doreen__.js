const userInfo = {
    firstName: 'Doreen',
    lastName: 'Tingir',
    hngId: 'HNG-03544',
    language: 'JavaScript',
    email: 'dtingir@gmail.com'
};
  
const response = `Hello World, this is [${userInfo.firstName}] [${userInfo.lastName}] with HNGi7 ID [${userInfo.hngId}] using [${userInfo.language}] for stage 2 task. ${userInfo.email}`;
  
console.log(response);