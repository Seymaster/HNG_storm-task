first_name = 'Ajayi'
last_name = 'Sodiq'
id = 'HNG-05120'
language = 'Python'
email = 'sodiq.ajayi@yahoo.com'

print(
    'Hello world, this is [{}] [{}] with HNGi7 ID [{}] using [{}] for stage 2 task. {}'
    .format(first_name, last_name, id, language, email))
