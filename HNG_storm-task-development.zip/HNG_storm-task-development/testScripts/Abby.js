var data = {
  firstName: "Esther",
  lastName: "Agiode",
  language: "Javascript",
  id: "HNG-04014",
  email: "estheragiode15.com",
};

console.log("Hello world, this is " + data.firstName + " " + data.lastName + " with HNGi7 ID " + data.id + " using " + data.language + " for stage 2 task. " + " " + data.email);

