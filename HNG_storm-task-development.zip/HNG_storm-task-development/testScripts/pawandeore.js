function  dataString(){
    var pawanData = {
        firstName: '[pawan]',
        lastName: '[deore]',
        id: '[HNG-01413]',
        language: '[JavaScript]',
        email: 'pavandeore90@gmail.com'
    };

    return  'Hello World, this is ' + pawanData.firstName+ ' ' +pawanData.lastName + ' with HNGi7 ID ' + pawanData.id + ' using ' + pawanData.language + ' for stage 2 task. ' + pawanData.email;
    }
    console.log(dataString());
