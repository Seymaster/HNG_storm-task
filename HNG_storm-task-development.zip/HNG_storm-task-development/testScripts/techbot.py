

def HNG():
    """
    this is the second task of the HNG intenship program. we are expected to output
    our name, id and language
    """



    firstName = "[Stanley]"
    LastName = "[Ekwebelem]"
    id = "[HNG-01260]"
    email = "stanleychibuike31@gmail.com"
    language = "[Python]"


    print("Hello World, this is " + firstName + " " + LastName  + " with HNGi7 ID " + id + " using " + language + " for stage 2 task. stanleychibuike31@gmail.com")


HNG()

