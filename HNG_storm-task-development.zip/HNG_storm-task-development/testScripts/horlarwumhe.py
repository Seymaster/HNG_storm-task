def task():
	firstname = "Akanji"
	lastname = "Olawumi"
	mail= "amachiever4real@gmail.com"
	print("Hello World, this is [%s] [%s] with HNGi7 ID [HNG-03537] using [Python] for stage 2 task. %s"%(firstname,lastname,mail))
task()