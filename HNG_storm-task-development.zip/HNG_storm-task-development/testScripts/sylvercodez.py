
#my default function 
def MY_details():

    #my default variable
    data = (FirstName = "[OTENAIKE]"
        LastName = "[OLUWATOBI]"
        Id = "[HNG-00465]"
        Language = "[python]"
        Email ='tosinotenaike3@gmail.com')

    #output of the code
    print("Hello World, this is", FirstName, LastName, "with HNGi7 ID", Id, "using", Language, "for stage 2 task.", Email)
MY_details()