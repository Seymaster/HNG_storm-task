Email = "adeyokunnuo@gmail.com"
Name  = "Oluwatobi Adeyokunnu"
ID = "HNG-02004"
Lang = "python"

print("Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task. {}".format(Name,ID,Lang, Email))
