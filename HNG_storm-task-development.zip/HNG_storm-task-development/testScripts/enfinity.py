def info(firstName,lastName,hngid,language,email):
    
    print("Hello World, this is {} {} with HNGi7 ID {} using {} for stage 2 task. {}".format(firstName,lastName,hngid,language,email))

info("[Festus]","[Owumi]","[HNG-04019]","[Python]","festusowumi@gmail.com")
