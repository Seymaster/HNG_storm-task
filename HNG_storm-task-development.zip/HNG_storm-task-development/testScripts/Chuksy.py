def my_hngi7_details():
    firstName = 'Chukwuma'
    LastName = 'Onuh'
    language = 'Python'
    HNGi7_ID = 'HNG-02260'
    email = 'onuhchukwuma12@gmail.com'
    print('Hello World, this is [{}] [{}] with HNGi7 ID [{}] using [{}] for stage 2 task. {}'.format(firstName, LastName, HNGi7_ID, language, email))
    
my_hngi7_details()


