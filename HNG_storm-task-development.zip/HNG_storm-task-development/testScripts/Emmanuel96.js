//Variables
const firstName = "Osemene";
const lastName = "Stephen"
const email = "stephenemmanuel770@gmail.com";
const id = "HNG-02164"
const language = "JavaScript";

//output
const output = `Hello World, this is [${firstName}] [${lastName}] with HNGi7 ID [${id}] using [${language}] for stage 2 task. ${email}`;

console.log(output);