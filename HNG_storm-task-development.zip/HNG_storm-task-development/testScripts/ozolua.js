function sentence(firstname,lastname, id,language,email){

  return `Hello World, this is ${firstname} ${lastname} with HNGi7 ID ${id} using ${language} for stage 2 task. ${email}`

}



console.log(sentence("[Calvin]","[Ebun-Amu]", "[HNG-00191]", "[JavaScript]", "calvinebunamu@gmail.com"))
