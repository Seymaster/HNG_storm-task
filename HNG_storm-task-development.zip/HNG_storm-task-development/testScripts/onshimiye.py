FIRSTNAME = 'Olivier'
LASTNAME = 'Nshimiye'
HNG_ID = 'HNG-00058'
LANG = 'Python'
EMAIL = 'onshimiye17@gmail.com'

print('Hello World, this is [{}] [{}] with HNGi7 ID [{}] using [{}] for stage 2 task. {}'.format(FIRSTNAME, LASTNAME,
                                                                                                 HNG_ID, LANG, EMAIL))
