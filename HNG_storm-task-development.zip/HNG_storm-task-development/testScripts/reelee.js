var myInfo=()=>{
	console.log("Hello World, this is [Rilwan] [Yusuf] with HNGi7 ID [HNG-04114] using [Javascript] for stage 2 task. akinyusuf5@gmail.com");
}
myInfo();