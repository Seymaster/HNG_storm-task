function output() {
  const data = {
    firstName: "Oluwayanmife",
    lastName: "Akeju",
    language: "PHP & JS",
    id: "HNG-00197",
  };
  str =
    "Hello World, this is [Oluwayanmitoe] [Akeju] with HNGi7 ID [HNG-00197] using [PHP] for stage 2 task. yanmifeakeju@gmail.com";

  return str;
}

//console.log(output());

console.log(output());
