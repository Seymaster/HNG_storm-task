firstName = "[Caleb]"
lastName = "[Agbeniga]"
hngID = "[HNG-00380]"
email = "agbenigacaleb@gmail.com"
language = "[Python]"

print("Hello World, this is {} {} with HNGi7 ID {} using {} for stage 2 task. {}".format(firstName,lastName,hngID,language, email))


