const firstName = "Chinaemerem";
const lastName = "Onyenucheya";
let id = "HNG-03653";
let lang = "JavaScript";
let email = "onyenaucheyaobinna1@gmail.com";

console.log(`Hello World,this is [${firstName}] [${lastName}] with HNGi7 ID [${id}] using [${lang}] for stage 2 task.${email}`);

