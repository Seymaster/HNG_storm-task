def record(d,a,c,r,u,z=None):
    print('Hello World, this is [{0}] [{1}] with HNGi7 ID [{3}] using [{2}] for stage 2 task. {4}'.format(d,a,c,r,u,z))


d = 'Chijioke'
a = 'Ikechukwu'
c = 'PYTHON'
r = 'HNG-05191'
u = 'chukslacafe@yahoo.com'
record(d,a,c,r,u)