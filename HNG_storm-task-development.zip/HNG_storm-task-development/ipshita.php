<?php
  $firstName = 'Ipshita';
  $lastName = 'Royburman';
  $hngID = 'HNG-06545';
  $progLang = 'PHP';
  $email = 'ipshitarburman@gmail.com';
  
  echo <<<HELLOWORLD
Hello World, this is [$firstName] [$lastName] with HNGi7 ID [$hngID] using [$progLang] for stage 2 task. [$email]
HELLOWORLD;
?>