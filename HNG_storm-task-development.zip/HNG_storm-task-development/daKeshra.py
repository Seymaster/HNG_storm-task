# My solution to HNGi7 stage to task 2

def my_hng_profile():

    #Declaring variables

    full_Name = "Keshinro Damilare"
    hng_id = "HNG-01340"
    lang_used = "Python"
    e_mail = "keshradamora@gmail.com"

    # Outputs the details
    print("Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task.{}".format(full_Name,hng_id,lang_used,e_mail) )

my_hng_profile()
