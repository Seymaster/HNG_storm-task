<?php

$firstName = "Gabriel";
$lastName = "Aggrey";

$internID = "HNG-00266";
$myEmail = "gabaggrey@gmail.com";
$languageOfChoice = "PHP";


echo "Hello World, this is " . $firstName . " " . $lastName . " with HNGi7 ID " . $internID . " using " . $languageOfChoice . " for stage 2 task. " . $myEmail ;

?>