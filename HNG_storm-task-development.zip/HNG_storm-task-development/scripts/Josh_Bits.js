function byc(){
  let myInfo = {
    firstName: "Joshua",
    lastName: "Onyemachi",
    language: "Javascript",
    id: "HNG-05690",
    email: "2sicryptofficial@gmail.com"
  };
  return "Hello World, this is " + myInfo.firstName + " " + myInfo.lastName + " with HNGi7 ID " + myInfo.id + " using " + myInfo.language + " for stage 2 task. " + myInfo.email
}
console.log(byc());
